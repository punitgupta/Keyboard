package com.test.aladdinbusinessapp;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.provider.Settings;
import android.view.WindowManager;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        Intent enableIntent = new Intent(Settings.ACTION_INPUT_METHOD_SETTINGS);
        enableIntent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        startActivity(enableIntent);




/*
        InputMethodManager imeManager = (InputMethodManager)
                getApplicationContext().getSystemService(INPUT_METHOD_SERVICE);
        imeManager.showInputMethodPicker();
        imeManager.getEnabledInputMethodList();

//com.test.aladdinbusinessapp/.SimpleIME

        if(imeManager.getInputMethodList().contains("com.test.aladdinbusinessapp/.SimpleIME"))
        {
            //get the old default keyboard in case you want to use it later, or keep it enabled
            //  String oldDefaultKeyboard = Settings.Secure.getString(resolver, Setting.Secure.DEFAULT_INPUT_METHOD);
            // To activate the keyboard
        }
        else
        {
            startActivity(new Intent("android.settings.INPUT_METHOD_SETTINGS"));
        }*/


    }
}